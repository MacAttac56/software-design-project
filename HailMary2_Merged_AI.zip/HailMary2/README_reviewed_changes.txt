HAIL MARY 2 - REVIEWED AUTHENTICATION PATCH

Use this project as a replacement for your current HailMary2 folder only after
making a backup.

INSTALL:
1. Extract this ZIP.
2. Copy the contents of the HailMary2 folder into:
   C:\xampp\htdocs\HailMary2\
3. Back up existing files before overwriting.
4. Keep the existing uploads/listings folder and its images.

WHAT WAS FIXED:
- Added auth.php for shared session startup, login checks, current Student_ID,
  and CSRF token handling.
- Login now establishes the session and redirects to HailMaryListings.php.
- Home, Listings, Messages, Report, Sign-Up, Access, Cart, Account, and Upload
  pages now use a consistent session-aware navigation.
- Cart view, add, remove, and checkout use the signed-in Student_ID instead
  of the old hardcoded Student_ID 1.
- Listing upload requires login and sets Seller_ID from the session. The old
  test seller dropdown is removed.
- Account update, listing delete, cart changes, listing uploads, and checkout use shared CSRF checks.
- Added a demo checkout button to the cart; it records a demo checkout and empties only that student's cart.
- Listing deletion removes Cart and Listing_Images rows before deleting the
  listing, matching the supplied foreign-key definitions.
- Added logout session cleanup.
- Added database setup scripts for Password_Hash (if missing), Checkout, and
  cart duplicate checking.

IMPORTANT DATABASE NOTES:
- Your supplied CREATE DATABASE SQL does NOT define Password_Hash, even though
  insert_student.php, HailMaryLogin.php, and HailMaryUpdateAccount.php use it.
  Check DESCRIBE Students first. If Password_Hash is absent, run
  add_password_hash_column.sql once.
- Your supplied SQL and cart_setup.sql do not define a Checkout table. Run
  checkout_setup.sql once if you want the current demo checkout handler to work.
- The checkout handler records a demo checkout only; it does not process payments.
- Run cart_duplicate_check.sql. If it returns no rows, uncomment and run the
  unique constraint statement once.
- Do not delete Student_ID 1 simply because it was the original test account.
  Existing listings, messages, reports, and conversations reference Student_ID 1.
  New activity will use the currently signed-in account.

AI POPUP:
- This ZIP does not contain HailMaryAI.php, ai_backend.php, or a separate AI
  popup script. I therefore cannot verify or change the AI popup behavior from
  this upload. The login handler in this ZIP does not redirect to an AI page.

TESTING LIMIT:
- Changes are based on the uploaded source. They still need to be run in your
  XAMPP/PHP/MariaDB setup and tested in a browser.
