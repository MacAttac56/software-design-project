<?php
// Keep your API key outside the public web folder where possible.
// Recommended: set HAILMARY_OPENAI_API_KEY in Apache/PHP environment.
// Optional fallback file path can be set with HAILMARY_OPENAI_KEY_FILE.
$key = getenv('HAILMARY_OPENAI_API_KEY') ?: '';
$keyFile = getenv('HAILMARY_OPENAI_KEY_FILE') ?: '';
if ($key === '' && $keyFile !== '' && is_readable($keyFile)) {
    $key = trim((string) file_get_contents($keyFile));
}
define('HAILMARY_OPENAI_API_KEY', trim($key));
define('HAILMARY_OPENAI_MODEL', getenv('HAILMARY_OPENAI_MODEL') ?: 'gpt-4o-mini');
?>
