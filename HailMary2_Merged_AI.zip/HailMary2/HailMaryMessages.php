<?php require_once __DIR__ . '/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Welcome to Hail Mary</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet">

    
    <link rel="stylesheet" href="HailMarystylesheet.css">
</head>

<body>

    <!-- Banner -->
    <header class="site-banner">
        <h1>Hail Mary</h1>
        <p>Buy, Sell, and Trade with College Students</p>
    </header>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="HailMaryhomepage.php">Hail Mary</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navMenu" aria-controls="navMenu"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryhomepage.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryListings.php">Listings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="HailMaryMessages.php">Messages</a>
                </li>
                <li class="nav-item"><a class="nav-link" href="HailMaryAI.php">AI Assistant</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryReport.php">Report</a>
                </li>
                <?php if (!empty($_SESSION['student_id'])): ?>
                    <li class="nav-item"><a class="nav-link" href="HailMaryCart.php">My Cart</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryAccount.php">My Account</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryLogout.php">Sign Out</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="HailMarysignup.php">Sign-Up</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryAccessPage.php">Sign In</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


   
    <main class="container py-4">
        <h2>Welcome to Hail Mary</h2>
        <p>Your campus marketplace starts here.</p>
    </main>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>