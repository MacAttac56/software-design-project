HAIL MARY MERGED BUILD

This folder combines the HailMary2 layout/navigation and the reviewed session-safe account/cart/listing fixes with the AI shopping assistant files from HailMaryTest.

INSTALL
1. Back up your current C:\xampp\htdocs\HailMary2 folder.
2. Copy the contents of this folder into C:\xampp\htdocs\HailMary2 (keep the uploads folder).
3. Keep your existing database. Check the SQL files before importing anything.
4. Confirm Students.Password_Hash exists; if not, run add_password_hash_column.sql.
5. Run checkout_setup.sql if the Checkout table does not exist. The included checkout implementation uses the shipping-information form from HailMaryTest, but ties orders to the signed-in student and validates the shared CSRF token.
6. Configure the OpenAI API key as an Apache/PHP environment variable named HAILMARY_OPENAI_API_KEY. Do not put the key in a publicly served PHP file. Optionally set HAILMARY_OPENAI_KEY_FILE to a readable file path outside htdocs.
7. Ensure PHP cURL and mbstring extensions are enabled in XAMPP.
8. Sign in; the login flow opens AI Assistant first, and the same session stays active as you navigate to Listings or other pages. The AI page requires a signed-in student.

IMPORTANT
- The AI assistant searches real active Listings and Categories using ai_tools.php. It does not complete purchases or process payments.
- The Test ZIP's ai_config.php used a macOS-specific key path. This merged version removes that path and supports environment configuration for Windows/XAMPP.
- The merged code has PHP syntax validation only; it has not been run against your local Apache/MariaDB or live OpenAI key.
- Existing old test records with Student_ID=1 are not automatically reassigned.
