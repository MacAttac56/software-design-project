<?php
require_once __DIR__ . '/auth.php';
requireLogin();
require_once __DIR__ . '/db.php';

$studentId = currentStudentId();
$csrfToken = ensureCsrfToken();

$sql = "SELECT c.Cart_ID, l.Listing_ID, l.Title, l.Price, c.Added_At
        FROM Cart c
        INNER JOIN Listings l ON c.Listing_ID = l.Listing_ID
        WHERE c.Student_ID = ?
        ORDER BY c.Added_At DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$studentId]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total = array_sum(array_column($cartItems, 'Price'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hail Mary | My Cart</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link rel="stylesheet" href="HailMarystylesheet.css">
</head>
<body>

<header class="site-banner">
    <h1>Hail Mary</h1>
    <p>Buy, Sell, and Trade with College Students</p>
</header>

<nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="HailMaryhomepage.php">Hail Mary</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navMenu" aria-controls="navMenu"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryhomepage.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryListings.php">Listings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryMessages.php">Messages</a>
                </li>
                <li class="nav-item"><a class="nav-link" href="HailMaryAI.php">AI Assistant</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="HailMaryReport.php">Report</a>
                </li>
                <?php if (!empty($_SESSION['student_id'])): ?>
                    <li class="nav-item"><a class="nav-link" href="HailMaryCart.php">My Cart</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryAccount.php">My Account</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryLogout.php">Sign Out</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="HailMarysignup.php">Sign-Up</a></li>
                    <li class="nav-item"><a class="nav-link" href="HailMaryAccessPage.php">Sign In</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


<main class="container py-5">

    <h2>My Shopping Cart</h2>

    <?php if (isset($_GET['checkout']) && $_GET['checkout'] === 'success'): ?>
        <div class="alert alert-success">Your demo checkout was recorded.</div>
    <?php endif; ?>
    <?php if (isset($_GET['empty'])): ?>
        <div class="alert alert-warning">Your cart is empty.</div>
    <?php endif; ?>
    <?php if (isset($_GET['error']) && $_GET['error'] === 'csrf'): ?>
        <div class="alert alert-warning">Your form expired. Refresh the page and try again.</div>
    <?php endif; ?>

    <?php if (isset($_GET['removed']) && $_GET['removed'] === '1'): ?>
        <div class="alert alert-success" role="status">
            Item removed from your cart.
        </div>
    <?php endif; ?>

    <?php if (empty($cartItems)): ?>

        <div class="alert alert-info mt-4">
            Your cart is empty.
            <a href="HailMaryListings.php">Browse listings</a> to find something.
        </div>

    <?php else: ?>

        <div class="table-responsive">
            <table class="table table-striped mt-4">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Date Added</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td>
                                <?= htmlspecialchars($item['Title'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                $<?= number_format((float)$item['Price'], 2) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($item['Added_At'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                <form method="POST" action="remove_from_cart.php">
                                    <input
                                        type="hidden"
                                        name="cart_id"
                                        value="<?= (int)$item['Cart_ID'] ?>">
                                    <input type="hidden" name="csrf_token"
                                           value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">

                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Remove
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h4 class="text-end">
            Total: $<?= number_format((float)$total, 2) ?>
        </h4>

        <div class="d-flex flex-wrap justify-content-end gap-2 mt-3">
            <a href="HailMaryListings.php" class="btn btn-outline-primary">
                Continue Shopping
            </a>
            <a href="checkout.php" class="btn btn-success">Continue to Checkout</a>
        </div>

    <?php endif; ?>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>