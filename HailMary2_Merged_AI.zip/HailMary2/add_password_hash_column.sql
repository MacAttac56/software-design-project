USE GroupHailMary;

-- Run this only if Students does not already have Password_Hash.
ALTER TABLE Students
ADD COLUMN Password_Hash VARCHAR(255) NULL;
