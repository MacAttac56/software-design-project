<?php
require_once __DIR__ . '/auth.php';
requireLogin();
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
    header('Location: HailMaryListings.php?error=csrf');
    exit;
}

$studentId = currentStudentId();
$listingId = filter_input(INPUT_POST, 'listing_id', FILTER_VALIDATE_INT);

if (!$listingId || $listingId < 1) {
    http_response_code(400);
    exit('Invalid listing');
}

try {
    $check = $pdo->prepare("
        SELECT Listing_ID, Seller_ID
        FROM Listings
        WHERE Listing_ID = ? AND Status = 'Active'
    ");
    $check->execute([$listingId]);
    $listing = $check->fetch(PDO::FETCH_ASSOC);

    if (!$listing) {
        http_response_code(404);
        exit('Listing not found');
    }

    if ((int)$listing['Seller_ID'] === $studentId) {
        header('Location: HailMaryListings.php?own_listing=1', true, 303);
        exit;
    }

    $duplicate = $pdo->prepare("
        SELECT Cart_ID FROM Cart
        WHERE Student_ID = ? AND Listing_ID = ?
        LIMIT 1
    ");
    $duplicate->execute([$studentId, $listingId]);

    if ($duplicate->fetchColumn()) {
        header('Location: HailMaryListings.php?duplicate=1', true, 303);
        exit;
    }

    $insert = $pdo->prepare("
        INSERT INTO Cart (Student_ID, Listing_ID)
        VALUES (?, ?)
    ");
    $insert->execute([$studentId, $listingId]);

    header('Location: HailMaryListings.php?added=1', true, 303);
    exit;

} catch (PDOException $e) {
    error_log('Hail Mary add-to-cart error: ' . $e->getMessage());
    http_response_code(500);
    exit('Could not add listing to cart. Please try again.');
}
?>
