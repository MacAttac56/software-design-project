<?php
// Start one consistent PHP session for every Hail Mary page.
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');

    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

function requireLogin(): void {
    if (
        empty($_SESSION['student_id']) ||
        !filter_var($_SESSION['student_id'], FILTER_VALIDATE_INT)
    ) {
        header('Location: HailMaryAccessPage.php?login_required=1');
        exit;
    }
}

function currentStudentId(): int {
    requireLogin();
    return (int) $_SESSION['student_id'];
}

function ensureCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token): bool {
    return (
        is_string($token) &&
        isset($_SESSION['csrf_token']) &&
        is_string($_SESSION['csrf_token']) &&
        hash_equals($_SESSION['csrf_token'], $token)
    );
}
?>
