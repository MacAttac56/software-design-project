
<?php
require_once __DIR__ . '/auth.php';
requireLogin();
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: HailMaryAccount.php');
    exit;
}

// Verify CSRF token.
if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
    header('Location: HailMaryAccount.php?error=1');
    exit;
}

$studentId = currentStudentId();
$listingId = filter_input(INPUT_POST, 'listing_id', FILTER_VALIDATE_INT);

if (!$listingId || $listingId <= 0) {
    header('Location: HailMaryAccount.php?error=1');
    exit;
}

try {
    $pdo->beginTransaction();

    // Confirm this listing belongs to the logged-in student.
    $stmt = $pdo->prepare("
        SELECT Listing_ID
        FROM Listings
        WHERE Listing_ID = ? AND Seller_ID = ?
        FOR UPDATE
    ");
    $stmt->execute([$listingId, $studentId]);

    if (!$stmt->fetch()) {
        $pdo->rollBack();
        header('Location: HailMaryAccount.php?error=1');
        exit;
    }

    // Remove cart references first (the supplied Cart FK has no cascade).
    $stmt = $pdo->prepare("DELETE FROM Cart WHERE Listing_ID = ?");
    $stmt->execute([$listingId]);

    // Remove associated image records.
    $stmt = $pdo->prepare("DELETE FROM Listing_Images WHERE Listing_ID = ?");
    $stmt->execute([$listingId]);

    // Delete the listing itself.
    $stmt = $pdo->prepare("
        DELETE FROM Listings
        WHERE Listing_ID = ? AND Seller_ID = ?
    ");
    $stmt->execute([$listingId, $studentId]);

    $pdo->commit();

    header('Location: HailMaryAccount.php?deleted=1');
    exit;

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    header('Location: HailMaryAccount.php?error=1');
    exit;
}
?>
