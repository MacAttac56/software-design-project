USE GroupHailMary;
CREATE TABLE IF NOT EXISTS Checkout (
    Checkout_ID INT AUTO_INCREMENT PRIMARY KEY,
    Student_ID INT NOT NULL,
    items_descriptions TEXT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    Full_Name VARCHAR(150) NOT NULL,
    Email VARCHAR(150) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    City VARCHAR(100) NOT NULL,
    State VARCHAR(50) NOT NULL,
    Zip_Code VARCHAR(20) NOT NULL,
    Payment_Method VARCHAR(50) NOT NULL DEFAULT 'Demo',
    Created_At TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_checkout_student
        FOREIGN KEY (Student_ID) REFERENCES Students(Student_ID)
);
