<?php
require_once __DIR__ . '/auth.php';
requireLogin();
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}
if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
    header('Location: HailMaryCart.php?error=csrf');
    exit;
}
$studentId = currentStudentId();
$cartId = filter_input(INPUT_POST, 'cart_id', FILTER_VALIDATE_INT);
if (!$cartId || $cartId < 1) {
    http_response_code(400);
    exit('Invalid cart item.');
}
try {
    $stmt = $pdo->prepare("DELETE FROM Cart WHERE Cart_ID = ? AND Student_ID = ?");
    $stmt->execute([$cartId, $studentId]);
    header('Location: HailMaryCart.php?removed=1', true, 303);
    exit;
} catch (PDOException $e) {
    error_log('Hail Mary remove-cart error: ' . $e->getMessage());
    http_response_code(500);
    exit('Could not remove item from cart.');
}
?>
