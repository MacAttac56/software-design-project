<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: HailMaryAccessPage.php');
    exit;
}
$email = trim($_POST['school_email'] ?? '');
$password = $_POST['password'] ?? '';

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    header('Location: HailMaryAccessPage.php?error=1');
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT Student_ID, Name, School_Email, Password_Hash
        FROM Students WHERE School_Email = ? LIMIT 1
    ");
    $stmt->execute([$email]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student || empty($student['Password_Hash']) ||
        !password_verify($password, $student['Password_Hash'])) {
        header('Location: HailMaryAccessPage.php?error=1');
        exit;
    }

    // Start a fresh session after the credentials are verified.
    $_SESSION = [];
    session_regenerate_id(true);
    $_SESSION['student_id'] = (int) $student['Student_ID'];
    $_SESSION['student_name'] = $student['Name'];
    $_SESSION['school_email'] = $student['School_Email'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['ai_csrf'] = bin2hex(random_bytes(32));
    $_SESSION['ai_history'] = [];

    // Open the marketplace first; AI remains available from navigation.
    header('Location: HailMaryListings.php?loggedin=1');
    exit;
} catch (PDOException $e) {
    error_log('Hail Mary login error: ' . $e->getMessage());
    http_response_code(500);
    exit('Unable to sign in right now. Please try again later.');
}
?>
