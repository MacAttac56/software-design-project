USE GroupHailMary;

-- Run this query first. If it returns no rows, there are no duplicates:
SELECT Student_ID, Listing_ID, COUNT(*) AS Duplicate_Count
FROM Cart
GROUP BY Student_ID, Listing_ID
HAVING COUNT(*) > 1;

-- If the query above returns no rows, run this statement once:
-- ALTER TABLE Cart
-- ADD CONSTRAINT uq_cart_student_listing UNIQUE (Student_ID, Listing_ID);
