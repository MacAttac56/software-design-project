
<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

$studentId = 1;

try {
    $pdo->beginTransaction();

    // Get items currently in the cart
    $stmt = $pdo->prepare("
        SELECT l.Title, l.Price
        FROM Cart c
        JOIN Listings l ON c.Listing_ID = l.Listing_ID
        WHERE c.Student_ID = ?
        FOR UPDATE
    ");
    $stmt->execute([$studentId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($items)) {
        $pdo->rollBack();
        header('Location: HailMaryCart.php?empty=1', true, 303);
        exit;
    }

    $descriptions = [];
    $total = 0;

    foreach ($items as $item) {
        $descriptions[] = $item['Title'];
        $total += (float)$item['Price'];
    }

    // Save one checkout record
    $insert = $pdo->prepare("
        INSERT INTO Checkout (items_descriptions, total_price)
        VALUES (?, ?)
    ");
    $insert->execute([
        implode(', ', $descriptions),
        number_format($total, 2, '.', '')
    ]);

    // Empty the cart for student 1
    $delete = $pdo->prepare("
        DELETE FROM Cart WHERE Student_ID = ?
    ");
    $delete->execute([$studentId]);

    $pdo->commit();

    header('Location: HailMaryCart.php?checkout=success', true, 303);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    http_response_code(500);
    exit('Checkout failed. Please try again.');
}
