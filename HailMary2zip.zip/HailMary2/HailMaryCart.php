<?php
require_once "db.php";

// Assignment demo: Student_ID 1
$studentId = 1;

$sql = "SELECT
            c.Cart_ID,
            l.Listing_ID,
            l.Title,
            l.Price,
            c.Added_At
        FROM Cart c
        JOIN Listings l ON c.Listing_ID = l.Listing_ID
        WHERE c.Student_ID = ?
        ORDER BY c.Added_At DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$studentId]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = array_sum(array_column($cartItems, 'Price'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hail Mary | My Cart</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link rel="stylesheet" href="HailMarystylesheet.css">
</head>
<body>

<header class="site-banner">
    <h1>Hail Mary</h1>
    <p>Buy, Sell, and Trade with College Students</p>
</header>

<nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="HailMaryhomepage.php">Hail Mary</a>

        <div class="navbar-nav ms-auto">
            <a class="nav-link" href="HailMaryhomepage.php">Home</a>
            <a class="nav-link" href="HailMaryListings.php">Listings</a>
            <a class="nav-link active" href="HailMaryCart.php">My Cart</a>
        </div>
    </div>
</nav>

<main class="container py-5">

    <h2>My Shopping Cart</h2>

    <?php if (isset($_GET['removed']) && $_GET['removed'] === '1'): ?>
        <div class="alert alert-success" role="status">
            Item removed from your cart.
        </div>
    <?php endif; ?>

    <?php if (empty($cartItems)): ?>

        <div class="alert alert-info mt-4">
            Your cart is empty.
            <a href="HailMaryListings.php">Browse listings</a> to find something.
        </div>

    <?php else: ?>

        <div class="table-responsive">
            <table class="table table-striped mt-4">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Date Added</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td>
                                <?= htmlspecialchars($item['Title'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                $<?= number_format((float)$item['Price'], 2) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($item['Added_At'], ENT_QUOTES, 'UTF-8') ?>
                            </td>

                            <td>
                                <form method="POST" action="remove_from_cart.php">
                                    <input
                                        type="hidden"
                                        name="cart_id"
                                        value="<?= (int)$item['Cart_ID'] ?>">

                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Remove
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h4 class="text-end">
            Total: $<?= number_format((float)$total, 2) ?>
        </h4>

        <div class="text-end mt-3">
            <a href="HailMaryListings.php" class="btn btn-outline-primary">
                Continue Shopping
            </a>
        </div>

    <?php endif; ?>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>